$(document).ready(()=>
  	 {
  		$('#log').click(()=>{
  		
  		 	alert("Successfully Registered");
  							 });
  	});